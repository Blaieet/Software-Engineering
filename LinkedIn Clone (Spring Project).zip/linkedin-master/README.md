## About
Projecte LinkedIn corresponent a l'assignatura d'Enginyeria del Software de l'Universitat de Barcelona

## Who

* Jordi Armengol
* Ivet Aymerich
* Sergi Martorell
* Martín Perez
* Oriol Rabasseda
* Blai Ras
* Joan Sitjà

## Technologies used

### Frontend

* jQuery
* Bootstrap

### Backend

* Java + Spring Framework
* SQL database

_Aquest projecte es purament educacional i no pretén en cap moment ser usat amb intencions de phishing o derivats_
