package com.ub.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ub.model.JobExperience;

public interface JobExperienceRepository extends JpaRepository<JobExperience, Long> {

}
