package com.ub.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ub.model.Studies;

public interface StudiesRepository extends JpaRepository<Studies, Long>{
	

}
