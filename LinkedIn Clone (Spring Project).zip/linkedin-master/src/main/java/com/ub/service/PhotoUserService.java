package com.ub.service;

public class PhotoUserService {

}
