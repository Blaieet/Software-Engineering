//insert into app_role (ROLE_ID, ROLE_NAME) values (1, 'ROLE_ADMIN');
//insert into app_role (ROLE_ID, ROLE_NAME) values (2, 'ROLE_USER');
