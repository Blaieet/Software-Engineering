var a = angular.module('crudaApp',['ngResource']);
